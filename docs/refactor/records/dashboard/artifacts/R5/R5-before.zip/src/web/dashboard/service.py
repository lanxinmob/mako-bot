from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Optional

from src.models.schemas import (
    AutonomyGoal,
    AutonomyProgressEvent,
    AutonomyTask,
    BotProfile,
    NoteRecord,
    RelationshipMemory,
    ThoughtTrace,
)
from src.services.storage import StorageService
from src.services.mako_context import default_mako_profile

# Keep the existing constant exports during the staged dashboard refactor.
from src.web.dashboard.roadmap.catalog import ROADMAP_GROUPS, ROADMAP_TASK_TITLES
from src.web.dashboard.roadmap.defaults import (
    BLOCKED_TASKS,
    DOING_TASKS,
    DONE_TASKS,
    STATUS_LABELS,
)
from src.web.dashboard.roadmap.evidence import (
    BLOCKED_REASON_OVERRIDES,
    GROUP_CRITERIA_TEMPLATES,
    GROUP_IMPLEMENTATION_BASIS,
    TASK_EVIDENCE_OVERRIDES,
)
from src.web.dashboard.schemas import AutonomySummary, DashboardSummary


class DashboardService:
    def __init__(self, storage: Optional[StorageService] = None) -> None:
        self.storage = storage or StorageService()

    def get_summary(
        self,
        *,
        bot_profile_id: Optional[str] = None,
        notes_limit: int = 100,
        profiles_limit: int = 100,
        relationship_limit: int = 100,
        thought_trace_limit: int = 100,
        autonomy_limit: int = 100,
        recent_records_limit: int = 100,
    ) -> DashboardSummary:
        bot_profile = self._get_bot_profile(bot_profile_id)
        profiles = self.storage.list_profiles()[:profiles_limit]
        goals = self.storage.list_autonomy_goals(limit=autonomy_limit)
        tasks = self.storage.list_autonomy_tasks(limit=autonomy_limit)
        events = self.storage.list_autonomy_progress_events(limit=autonomy_limit)

        return DashboardSummary(
            profile=bot_profile,
            notes=self.storage.list_all_notes(limit=notes_limit),
            profiles=profiles,
            relationship_memories=self.storage.list_all_relationship_memories(limit=relationship_limit),
            thought_traces=self.storage.list_thought_traces(limit=thought_trace_limit),
            goals=goals,
            tasks=tasks,
            events=events,
            autonomy=AutonomySummary(goals=goals, tasks=tasks, events=events),
            recent_records=self.storage.list_global_records(limit=recent_records_limit),
        )

    def get_frontend_summary(self, *, limit: int = 200) -> dict:
        summary = self.get_summary(
            notes_limit=limit,
            profiles_limit=limit,
            relationship_limit=limit,
            thought_trace_limit=limit,
            autonomy_limit=max(limit, 100),
            recent_records_limit=limit,
        )
        profile = summary.profile or self._default_profile()
        roadmap_tasks = self._roadmap_tasks(summary.goals, summary.tasks, summary.events)
        roadmap_groups = self._roadmap_groups(roadmap_tasks)
        progress = self._progress(roadmap_tasks, summary.events)
        notes = self._format_notes(summary.notes)
        long_term_memory = self._format_long_term_memory(self.storage.list_long_term_memory_points(limit=limit))
        people = self._format_people(summary.profiles, summary.relationship_memories)
        thought_traces = self._format_traces(summary.thought_traces)
        recent_progress = self._format_recent_progress(summary.events)
        mako_profile = self._format_mako_profile(profile, roadmap_tasks, summary.thought_traces)

        data = summary.model_dump(mode="json")
        data.update(
            {
                "overview": {
                    "progress_percent": progress["percent"],
                    "status_label": progress["streak"],
                    "updated_at": progress["updated_at"],
                    "counts": {
                        "notes": len(notes) + len(long_term_memory),
                        "people": len(people),
                        "relationship_memories": len(summary.relationship_memories),
                        "thought_traces": len(thought_traces),
                        "roadmap_tasks": len(roadmap_tasks),
                    },
                },
                "progress": progress,
                "mako_profile": mako_profile,
                "mako_psych_profile": mako_profile,
                "notes": notes,
                "memory_notes": notes + long_term_memory,
                "long_term_memory": long_term_memory,
                "people": people,
                "user_profiles": {"items": people, "latest": people[0] if people else None, "total": len(people)},
                "relationship_memories": [
                    self._format_relationship_memory(memory) for memory in summary.relationship_memories
                ],
                "thought_traces": thought_traces,
                "thinking_summary": thought_traces[0]["summary"] if thought_traces else "",
                "roadmap_tasks": roadmap_tasks,
                "roadmap_groups": roadmap_groups,
                "autonomy": {
                    "goals": [goal.model_dump(mode="json") for goal in summary.goals],
                    "tasks": [task.model_dump(mode="json") for task in summary.tasks],
                    "events": [event.model_dump(mode="json") for event in summary.events],
                    "tree": self._build_goal_tree(summary.goals or self._default_goals(), summary.tasks),
                    "recent_progress": recent_progress,
                },
                "goals": self._build_goal_tree(summary.goals or self._default_goals(), summary.tasks),
                "recent_progress": recent_progress,
                "raw": summary.model_dump(mode="json"),
            }
        )
        return {"ok": True, "data": data}

    def _get_bot_profile(self, profile_id: Optional[str]) -> Optional[BotProfile]:
        if profile_id:
            return self.storage.get_bot_profile(profile_id)
        profiles = self.storage.list_bot_profiles(status="active", limit=1)
        if profiles:
            return profiles[0]
        profiles = self.storage.list_bot_profiles(limit=1)
        return profiles[0] if profiles else None

    def _default_profile(self) -> BotProfile:
        return default_mako_profile()

    def _default_goals(self) -> list[AutonomyGoal]:
        return [
            AutonomyGoal(
                goal_id=group_id,
                title=title,
                summary=summary,
                status="active",
                progress=0,
                source="roadmap",
                scope=group_id,
                priority=100 - index,
                reason=summary,
            )
            for index, (group_id, title, summary) in enumerate(ROADMAP_GROUPS)
        ]

    def _roadmap_tasks(
        self,
        persisted_goals: list[AutonomyGoal],
        persisted_tasks: list[AutonomyTask],
        events: list[AutonomyProgressEvent],
    ) -> list[dict]:
        tasks: list[dict] = []
        evidence_by_task = {event.task_id: event for event in events if event.task_id}
        persisted_by_title = {task.title: task for task in persisted_tasks}

        number = 1
        for group_id, group_title, _summary in ROADMAP_GROUPS:
            for task_index, title in enumerate(ROADMAP_TASK_TITLES[group_id], start=1):
                task_id = self._task_id(group_id, task_index)
                persisted = persisted_by_title.get(title)
                status = persisted.status if persisted else self._default_task_status(task_id)
                evidence = persisted.evidence if persisted else ""
                if not evidence:
                    evidence = self._task_evidence(task_id, group_id, status)
                if evidence_by_task.get(task_id):
                    evidence = evidence_by_task[task_id].summary
                summary = persisted.summary if persisted else self._task_detail_summary(group_id, title, status)
                next_step = persisted.next_step if persisted else self._next_step_for_task(task_id, group_id, title, status)
                criteria = self._completion_criteria(group_id, title)
                why_status = self._why_status(task_id, group_id, status, evidence)
                tasks.append(
                    {
                        "id": task_id,
                        "number": number,
                        "group_id": group_id,
                        "group_title": group_title,
                        "title": persisted.title if persisted else title,
                        "summary": summary,
                        "status": status,
                        "status_label": STATUS_LABELS.get(status, status),
                        "done": status == "done",
                        "evidence": evidence,
                        "completion_criteria": criteria,
                        "completion_basis": self._completion_basis(task_id, group_id, status, evidence),
                        "verification": self._verification_for_task(task_id, group_id, status),
                        "why_status": why_status,
                        "next_step": next_step,
                        "priority": persisted.priority if persisted else 100 - number,
                        "updated_at": (
                            persisted.updated_at.isoformat()
                            if persisted and persisted.updated_at
                            else None
                        ),
                    }
                )
                number += 1

        persisted_titles = {item["title"] for item in tasks}
        for task in persisted_tasks:
            if task.title in persisted_titles:
                continue
            status = task.status
            criteria = self._completion_criteria(task.goal_id or "custom", task.title)
            evidence = task.evidence or self._task_evidence(task.task_id, task.goal_id or "custom", status)
            tasks.append(
                {
                    "id": task.task_id,
                    "number": len(tasks) + 1,
                    "group_id": task.goal_id or "custom",
                    "group_title": "额外任务",
                    "title": task.title,
                    "summary": task.summary,
                    "status": status,
                    "status_label": STATUS_LABELS.get(status, status),
                    "done": status == "done",
                    "evidence": evidence,
                    "completion_criteria": criteria,
                    "completion_basis": self._completion_basis(task.task_id, task.goal_id or "custom", status, evidence),
                    "verification": self._verification_for_task(task.task_id, task.goal_id or "custom", status),
                    "why_status": self._why_status(task.task_id, task.goal_id or "custom", status, evidence),
                    "next_step": task.next_step,
                    "priority": task.priority,
                    "updated_at": task.updated_at.isoformat() if task.updated_at else None,
                }
            )
        return tasks

    def _roadmap_groups(self, tasks: list[dict]) -> list[dict]:
        groups: list[dict] = []
        by_group: dict[str, list[dict]] = defaultdict(list)
        for task in tasks:
            by_group[task["group_id"]].append(task)
        for group_id, title, summary in ROADMAP_GROUPS:
            items = by_group.get(group_id, [])
            done = len([task for task in items if task["status"] == "done"])
            groups.append(
                {
                    "id": group_id,
                    "title": title,
                    "summary": summary,
                    "total": len(items),
                    "done": done,
                    "progress": round(done / len(items) * 100) if items else 0,
                    "tasks": items,
                }
            )
        return groups

    def _progress(self, tasks: list[dict], events: list[AutonomyProgressEvent]) -> dict:
        total = len(tasks)
        done = len([task for task in tasks if task["status"] == "done"])
        doing = len([task for task in tasks if task["status"] == "doing"])
        blocked = len([task for task in tasks if task["status"] == "blocked"])
        percent = round(done / total * 100) if total else 0
        achieved = percent >= 100
        return {
            "percent": percent,
            "done": done,
            "doing": doing,
            "blocked": blocked,
            "todo": len([task for task in tasks if task["status"] == "todo"]),
            "total": total,
            "label": "100 项自主意志 v1 路线图",
            "streak": "自主意志 v1 达成" if achieved else f"{done}/{total} 项完成，{doing} 项推进中",
            "updated_at": self._format_time(events[0].created_at if events else datetime.now()),
            "achieved": achieved,
        }

    def _format_mako_profile(
        self,
        profile: BotProfile,
        roadmap_tasks: list[dict],
        traces: list[ThoughtTrace],
    ) -> dict:
        status_counts = Counter(task["status"] for task in roadmap_tasks)
        latest_trace = traces[0] if traces else None
        return {
            "id": profile.profile_id,
            "name": profile.name,
            "title": profile.current_stage or "自主意志 v1 修行中",
            "mood": profile.autonomy_statement or profile.summary,
            "summary": profile.summary,
            "persona": profile.persona,
            "values": profile.values,
            "boundaries": profile.boundaries,
            "traits": profile.capabilities or profile.values,
            "capabilities": profile.capabilities,
            "limitations": profile.limitations,
            "current_stage": profile.current_stage,
            "autonomy_statement": profile.autonomy_statement,
            "psychological_snapshot": [
                f"完成 {status_counts.get('done', 0)} 项基础能力，仍有 {status_counts.get('todo', 0)} 项待推进。",
                "倾向于低风险直接行动，中风险询问 owner，高风险保持沉默。",
                "目前的自我意识是工程可观测 v1：目标、记忆、审计摘要和受限行动闭环。",
                f"最近思考摘要：{latest_trace.summary}" if latest_trace else "最近还没有新的可审计思考摘要。",
            ],
            "updated_at": profile.updated_at.isoformat(),
        }

    def _format_notes(self, notes: list[NoteRecord]) -> list[dict]:
        return [
            {
                "id": note.note_id,
                "note_id": note.note_id,
                "user_id": note.user_id,
                "title": note.title,
                "content": note.content,
                "category": note.category,
                "visibility": note.visibility,
                "source": "notes",
                "created_at": note.created_at.isoformat(),
                "updated_at": note.updated_at.isoformat(),
            }
            for note in notes
        ]

    def _format_long_term_memory(self, points: list[dict]) -> list[dict]:
        return [
            {
                "id": point.get("id") or f"long-term-{index}",
                "note_id": point.get("id") or f"long-term-{index}",
                "user_id": None,
                "title": point.get("title") or "长期记忆",
                "content": point.get("content") or "",
                "category": point.get("category") or "long_term_memory",
                "visibility": "private",
                "source": point.get("source") or "vector_store",
                "created_at": None,
                "updated_at": None,
            }
            for index, point in enumerate(points)
        ]

    def _format_people(
        self,
        profiles: list[dict],
        relationship_memories: list[RelationshipMemory],
    ) -> list[dict]:
        memories_by_user: dict[int, list[RelationshipMemory]] = defaultdict(list)
        for memory in relationship_memories:
            memories_by_user[memory.user_id].append(memory)

        people = []
        for profile in profiles:
            user_id = self._optional_int(profile.get("user_id"))
            memory_items = memories_by_user.get(user_id or -1, [])
            profile_text = str(profile.get("profile_text") or "")
            people.append(
                {
                    "id": str(user_id or profile.get("nickname") or len(people)),
                    "user_id": user_id,
                    "name": profile.get("nickname") or f"用户 {user_id}",
                    "nickname": profile.get("nickname") or "",
                    "profile_text": profile_text,
                    "focus": self._first_profile_line(profile_text),
                    "preferences": self._extract_profile_section(profile_text, "偏好"),
                    "tags": self._profile_tags(profile_text),
                    "relationship_memories": [
                        self._format_relationship_memory(memory) for memory in memory_items
                    ],
                    "memory_count": len(memory_items),
                    "last_updated": profile.get("last_updated") or "",
                }
            )
        people.sort(key=lambda item: item.get("last_updated") or "", reverse=True)
        return people

    def _format_relationship_memory(self, memory: RelationshipMemory) -> dict:
        return {
            "id": memory.memory_id,
            "memory_id": memory.memory_id,
            "user_id": memory.user_id,
            "type": memory.memory_type,
            "content": memory.content,
            "source": memory.source,
            "status": memory.status,
            "confidence": memory.confidence,
            "created_at": memory.created_at.isoformat(),
            "due_at": memory.due_at.isoformat() if memory.due_at else None,
        }

    def _format_traces(self, traces: list[ThoughtTrace]) -> list[dict]:
        return [self._format_trace_record(trace) for trace in traces]

    def _format_trace_record(self, trace: ThoughtTrace) -> dict:
        payload = trace.payload or {}
        trace_type = trace.trace_type or trace.trace_kind
        input_summary = trace.input_summary or self._payload_input_summary(trace, payload)
        context_summary = trace.context_summary or self._payload_context_summary(trace, payload)
        retrieved_summary = trace.retrieved_summary or self._payload_retrieved_summary(trace, payload)
        decision_summary = trace.decision_summary or self._payload_decision_summary(trace, payload)
        output_summary = trace.output_summary or self._payload_output_summary(trace, payload)
        safety_notes = trace.safety_notes or "仅展示可审计摘要，不展示也不保存隐藏推理链。"
        target_label = self._trace_target_label(trace, payload)
        summary = self._format_trace(trace)
        title = self._trace_title(trace.source, trace_type)
        return {
            "id": trace.trace_id,
            "trace_id": trace.trace_id,
            "title": title,
            "source": trace.source,
            "trace_type": trace_type,
            "type": trace_type,
            "summary": summary,
            "body": summary,
            "input_summary": input_summary,
            "context_summary": context_summary,
            "retrieved_summary": retrieved_summary,
            "decision_summary": decision_summary,
            "output_summary": output_summary,
            "safety_notes": safety_notes,
            "trigger_source": self._trigger_source_label(trace, payload, input_summary),
            "context_observed": context_summary,
            "retrieved_memory": self._split_summary(retrieved_summary),
            "decision_result": decision_summary,
            "final_output": output_summary,
            "audit_note": "这里是审计摘要：记录输入/上下文/检索/决策/输出的可复核结论，不记录隐藏推理链。",
            "target_label": target_label,
            "tags": [item for item in [trace.source, trace_type, target_label] if item],
            "user_id": trace.user_id,
            "group_id": trace.group_id,
            "payload": self._safe_trace_payload(payload),
            "created_at": trace.created_at.isoformat(),
        }

    def _format_recent_progress(self, events: list[AutonomyProgressEvent]) -> list[dict]:
        return [
            {
                "id": event.event_id,
                "time": self._format_time(event.created_at),
                "title": event.summary,
                "source": event.source,
                "event_type": event.event_type or event.event_kind,
                "payload": event.payload,
            }
            for event in events[:30]
        ]

    def _build_goal_tree(self, goals: list[AutonomyGoal], tasks: list[AutonomyTask]) -> list[dict]:
        tasks_by_goal: dict[str, list[AutonomyTask]] = defaultdict(list)
        for task in tasks:
            if task.goal_id:
                tasks_by_goal[task.goal_id].append(task)
        return [
            {
                "id": goal.goal_id,
                "title": goal.title,
                "done": goal.status in {"achieved", "completed"},
                "progress": goal.progress or self._calculate_task_progress(tasks_by_goal.get(goal.goal_id, [])),
                "children": [self._task_to_node(task) for task in tasks_by_goal.get(goal.goal_id, [])],
            }
            for goal in goals
        ]

    def _task_to_node(self, task: AutonomyTask) -> dict:
        return {
            "id": task.task_id,
            "title": task.title,
            "done": task.status == "done",
            "status": task.status,
            "progress": 100 if task.status == "done" else None,
            "summary": task.summary,
            "evidence": task.evidence,
            "next_step": task.next_step,
        }

    @staticmethod
    def _task_id(group_id: str, task_index: int) -> str:
        return f"{group_id}-{task_index:02d}"

    @staticmethod
    def _default_task_status(task_id: str) -> str:
        if task_id in DONE_TASKS:
            return "done"
        if task_id in DOING_TASKS:
            return "doing"
        if task_id in BLOCKED_TASKS:
            return "blocked"
        return "todo"

    @staticmethod
    def _task_summary(group_id: str) -> str:
        return dict((group_id, summary) for group_id, _title, summary in ROADMAP_GROUPS).get(group_id, "")

    def _task_detail_summary(self, group_id: str, title: str, status: str) -> str:
        group_summary = self._task_summary(group_id)
        status_label = STATUS_LABELS.get(status, status)
        return f"{group_summary} 当前任务是“{title}”，状态为{status_label}；展开可查看完成判定、依据、验证方式和下一步。"

    @staticmethod
    def _next_step_for_status(status: str) -> str:
        if status == "done":
            return "保持事件驱动更新，继续观察真实运行。"
        if status == "doing":
            return "补齐真实数据接入与 owner 验收反馈。"
        if status == "blocked":
            return "需要服务器运行数据或 owner 规则进一步确认。"
        return "等待后续实现与真实运行验证。"

    def _next_step_for_task(self, task_id: str, group_id: str, title: str, status: str) -> str:
        if status == "done":
            return "保持当前实现，并继续让真实聊天、审批和发送事件覆盖默认完成依据。"
        if status == "doing":
            return f"补齐“{title}”的真实运行样例、owner 验收反馈和自动进度事件。"
        if status == "blocked":
            return BLOCKED_REASON_OVERRIDES.get(
                task_id,
                f"先收集服务器真实数据或 owner 规则，明确“{title}”的验收口径后再推进。",
            )
        return f"实现“{title}”对应的数据写入、读取、展示和至少一次可复核验证。"

    def _completion_criteria(self, group_id: str, title: str) -> list[str]:
        templates = GROUP_CRITERIA_TEMPLATES.get(
            group_id,
            [
                "存在对应的数据结构、实现路径或配置项。",
                "能在仪表盘或事件流水中看到该任务的状态和依据。",
                "缺少真实验证时不能判定为完成。",
            ],
        )
        return [template.format(title=title) for template in templates]

    def _completion_basis(self, task_id: str, group_id: str, status: str, evidence: str) -> list[str]:
        basis = []
        if evidence:
            basis.append(evidence)
        group_basis = GROUP_IMPLEMENTATION_BASIS.get(group_id)
        if group_basis:
            basis.append(group_basis)
        if status == "done":
            basis.append("该任务在当前 100 项路线图基线中被标记为 done，并有代码路径或配置作为支撑。")
        elif status == "doing":
            basis.append("已有部分实现或数据入口，但还缺真实运行样例、统计闭环或 owner 验收。")
        elif status == "blocked":
            basis.append("当前缺少足够规则、样本或自动化闭环，不能只靠设想判定完成。")
        else:
            basis.append("尚未看到对应实现或真实事件，保持待办。")
        return list(dict.fromkeys(item for item in basis if item))

    def _task_evidence(self, task_id: str, group_id: str, status: str) -> str:
        if task_id in TASK_EVIDENCE_OVERRIDES:
            return TASK_EVIDENCE_OVERRIDES[task_id]
        if status == "done":
            return GROUP_IMPLEMENTATION_BASIS.get(group_id, "已有当前代码或配置提供基础能力。")
        if status == "doing":
            return f"{GROUP_IMPLEMENTATION_BASIS.get(group_id, '已有部分入口。')} 仍需要更多真实事件或策略回写来完成验收。"
        if status == "blocked":
            return BLOCKED_REASON_OVERRIDES.get(task_id, "缺少真实运行样例、owner 规则或自动化闭环，暂不能验收。")
        return "尚未发现可证明完成的代码路径或事件记录。"

    def _why_status(self, task_id: str, group_id: str, status: str, evidence: str) -> str:
        status_label = STATUS_LABELS.get(status, status)
        if status == "done":
            return f"判定为{status_label}，因为当前实现已经覆盖主要入口，并能通过仪表盘或事件流水被 owner 查看。"
        if status == "doing":
            return f"判定为{status_label}，因为已有基础入口，但还需要真实运行数据、owner 反馈或自动回写来完成闭环。"
        if status == "blocked":
            return f"判定为{status_label}，因为{BLOCKED_REASON_OVERRIDES.get(task_id, evidence or '缺少关键验收条件')}。"
        return f"判定为{status_label}，因为目前还没有足够实现证据；需要先完成对应代码、数据和验证。"

    def _verification_for_task(self, task_id: str, group_id: str, status: str) -> str:
        if group_id == "dashboard":
            return "打开 /mako/dashboard?token=...，确认该模块有内容、可搜索/筛选，移动端不重叠；API 不能泄露密钥或隐藏推理链。"
        if group_id == "memory":
            return "在 Redis 有数据和 Redis 不可用两种场景下调用 dashboard summary，确认旧 key 与新模型记录都能展示。"
        if group_id == "decision":
            return "构造 owner 建议和近期上下文，确认决策 JSON 字段完整，非法/歧义输出被本地规则降级或转问 owner。"
        if group_id == "safety":
            return "用未白名单、冷却中、中风险、高风险和预算不足样例验证不会直接发送，并写入拒绝/静默事件。"
        if group_id == "action":
            return "用批准、取消、改写和发送失败四类 pending 流程验证消息发送、冷却、日志和全局记录。"
        if group_id == "perception":
            return "喂入群聊/私聊/多个 QQ/未指明目标样例，检查目标类型和 ask_owner 分支是否正确。"
        if group_id == "learning":
            return "积累 owner 批准、取消、改写样例后，检查统计、归因和下一次决策提示是否可见。"
        if group_id == "reflection":
            return "触发定期或手动复盘，确认生成 ThoughtTrace、更新目标/任务状态，并明确不保存隐藏推理链。"
        if group_id == "milestone":
            return "所有能力组达到完成判定后，检查总进度为 100%，并写入“自主意志 v1 达成”进度事件。"
        return "运行 py_compile/API smoke test，并用至少一条真实事件验证该任务能被仪表盘展示。"

    @staticmethod
    def _calculate_task_progress(tasks: list[AutonomyTask]) -> int:
        if not tasks:
            return 0
        done = len([task for task in tasks if task.status == "done"])
        return round(done / len(tasks) * 100)

    @staticmethod
    def _first_profile_line(profile_text: str) -> str:
        for line in profile_text.splitlines():
            line = line.strip()
            if line:
                return line
        return "还没有写入档案"

    @staticmethod
    def _extract_profile_section(profile_text: str, section: str) -> list[str]:
        marker = f"【{section}】"
        if marker not in profile_text:
            return []
        text = profile_text.split(marker, 1)[1].split("【", 1)[0]
        return [line.strip(" -:：") for line in text.splitlines() if line.strip(" -:：")]

    @staticmethod
    def _profile_tags(profile_text: str) -> list[str]:
        tags = []
        for marker in ["【核心特质】", "【行为模式】", "【关系定位】", "【茉子认知画像】"]:
            if marker in profile_text:
                tags.append(marker.strip("【】"))
        return tags

    @staticmethod
    def _trace_title(source: str, trace_type: str) -> str:
        labels = {
            "chat_reply_generated": "聊天回复生成",
            "decision_made": "自主行动决策",
            "note_write_summary": "笔记写入摘要",
            "note_update_summary": "笔记更新摘要",
            "relationship_extraction": "关系记忆抽取",
        }
        return labels.get(trace_type, trace_type or source or "思考摘要")

    @staticmethod
    def _trigger_source_label(trace: ThoughtTrace, payload: dict, input_summary: str) -> str:
        parts = []
        if trace.source:
            parts.append(trace.source)
        if trace.trace_type or trace.trace_kind:
            parts.append(trace.trace_type or trace.trace_kind)
        if trace.user_id:
            parts.append(f"用户 {trace.user_id}")
        if trace.group_id:
            parts.append(f"群 {trace.group_id}")
        suggestion = payload.get("suggestion_preview")
        if suggestion:
            parts.append(f"owner 建议：{suggestion}")
        elif input_summary:
            parts.append(input_summary)
        return " / ".join(str(part) for part in parts if part)

    @staticmethod
    def _trace_target_label(trace: ThoughtTrace, payload: dict) -> str:
        target_type = payload.get("target_type")
        target_id = payload.get("target_id")
        if target_type and target_id:
            label = "群聊" if target_type == "group" else "私聊" if target_type == "private" else "目标"
            return f"{label} {target_id}"
        if trace.group_id:
            return f"群聊 {trace.group_id}"
        if trace.user_id:
            return f"用户 {trace.user_id}"
        return ""

    @staticmethod
    def _payload_input_summary(trace: ThoughtTrace, payload: dict) -> str:
        for key in ["input_preview", "suggestion_preview", "text_preview", "content_preview", "title"]:
            value = payload.get(key)
            if value:
                return str(value)
        return trace.summary or "旧记录未保存触发输入摘要。"

    @staticmethod
    def _payload_context_summary(trace: ThoughtTrace, payload: dict) -> str:
        if trace.source == "autonomy":
            target_hint = payload.get("target_hint")
            recent_count = payload.get("recent_record_count")
            context_preview = payload.get("context_preview")
            return (
                f"读取 {recent_count if recent_count is not None else '若干'} 条近期记录；"
                f"目标解析提示：{target_hint or '旧记录未保存'}；"
                f"上下文预览：{context_preview or '旧记录未保存'}"
            )
        if trace.source == "chat":
            return (
                "普通聊天回复会结合当前消息、历史上下文、用户档案/关系记忆和茉子人格提示。"
                f" 历史轮数：{payload.get('history_turns', '旧记录未保存')}。"
            )
        if trace.source == "notes":
            return "笔记事件来自 owner 或聊天触发的记忆沉淀，并同步到笔记存储与向量索引。"
        if trace.source == "relationship":
            return str(payload.get("text_preview") or "关系记忆抽取来自用户消息中的偏好、禁忌、事件或承诺。")
        return "旧记录未保存上下文摘要。"

    @staticmethod
    def _payload_retrieved_summary(trace: ThoughtTrace, payload: dict) -> str:
        if trace.source == "autonomy":
            return (
                "近期 all_memory、群/私聊白名单、动态白名单、冷却状态、GovernanceService 限制。"
                f" 群白名单={payload.get('allowed_groups') or '旧记录未保存'}；"
                f"私聊白名单={payload.get('allowed_private_users') or '旧记录未保存'}。"
            )
        if trace.source == "chat":
            return (
                f"用户画像摘要：{payload.get('profile_preview') or '旧记录未保存'}；"
                f"知识/记忆检索摘要：{payload.get('knowledge_preview') or '旧记录未保存'}。"
            )
        if trace.source == "notes":
            return "写入 notes:* 后可被 list_all_notes 和向量索引读取。"
        if trace.source == "relationship":
            memories = payload.get("memories")
            if isinstance(memories, list) and memories:
                return "；".join(
                    str(item.get("content_preview") or item.get("memory_type") or item)
                    for item in memories
                    if isinstance(item, dict)
                )
            types = payload.get("memory_types")
            if types:
                return f"抽取类型：{types}"
        return "旧记录未保存检索记忆摘要。"

    @staticmethod
    def _payload_decision_summary(trace: ThoughtTrace, payload: dict) -> str:
        if trace.source == "autonomy" or trace.trace_type == "decision_made":
            return (
                f"action={payload.get('action', 'unknown')}；"
                f"target={payload.get('target_type', 'none')}:{payload.get('target_id', 'none')}；"
                f"confidence={payload.get('confidence', 'unknown')}；"
                f"risk={payload.get('risk', 'unknown')}；"
                f"reason={payload.get('reason', '未保存原因')}"
            )
        if trace.source == "chat":
            return f"生成普通聊天回复；模型={payload.get('model', 'unknown')}；没有把隐藏推理链写入记录。"
        if trace.source == "notes":
            return "将笔记变更沉淀为可检索记忆，不产生主动发言。"
        if trace.source == "relationship":
            return f"抽取并保存 {payload.get('memory_count', 0)} 条关系记忆，同步用户档案。"
        return "旧记录未保存结构化决策摘要。"

    @staticmethod
    def _payload_output_summary(trace: ThoughtTrace, payload: dict) -> str:
        for key in ["reply_preview", "message_preview", "content_preview"]:
            value = payload.get(key)
            if value:
                return str(value)
        if trace.source == "notes":
            title = payload.get("title")
            return f"笔记已更新：{title}" if title else "笔记已更新。"
        if trace.source == "relationship":
            return "关系记忆已写入存储、用户档案和笔记索引。"
        return "旧记录未保存最终输出摘要。"

    @staticmethod
    def _safe_trace_payload(payload: dict) -> dict:
        blocked_keys = {"api_key", "token", "authorization", "password", "secret", "prompt", "messages"}
        safe = {}
        for key, value in payload.items():
            lowered = str(key).lower()
            if any(blocked in lowered for blocked in blocked_keys):
                safe[key] = "[redacted]"
            else:
                safe[key] = value
        return safe

    @staticmethod
    def _split_summary(value: str) -> list[str]:
        if not value:
            return []
        parts = []
        for chunk in str(value).replace("\n", "；").split("；"):
            chunk = chunk.strip(" -:：")
            if chunk:
                parts.append(chunk)
        return parts[:8]

    @staticmethod
    def _format_trace(trace: ThoughtTrace) -> str:
        pieces = [
            trace.summary,
            trace.context_summary,
            trace.retrieved_summary,
            trace.decision_summary,
            trace.output_summary,
            trace.safety_notes,
        ]
        return "\n".join(piece for piece in pieces if piece).strip()

    @staticmethod
    def _optional_int(value: Any) -> Optional[int]:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _format_time(value: datetime) -> str:
        return value.strftime("%Y-%m-%d %H:%M")
